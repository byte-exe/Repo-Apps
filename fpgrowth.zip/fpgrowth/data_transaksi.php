<?php
if (!isset($_SESSION['fpg_id'])) {
    header("location:index.php?menu=forbidden");
}

include_once "database.php";
include_once "fungsi.php";
include_once "import/excel_reader2.php";
?>
<section class="page_head">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="page_title">
                    <h2>Data Transaksi</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
//object database class
$db_object = new database();

$pesan_error = $pesan_success = "";
if(isset($_GET['pesan_error'])){
    $pesan_error = $_GET['pesan_error'];
}
if(isset($_GET['pesan_success'])){
    $pesan_success = $_GET['pesan_success'];
}


if(isset($_POST['submit'])){
    // if(!$input_error){
    // upload file xls
    $target = basename($_FILES['file_data_transaksi']['name']) ;
    move_uploaded_file($_FILES['file_data_transaksi']['tmp_name'], $target);
     
    // beri permisi agar file xls dapat di baca
    chmod($_FILES['file_data_transaksi']['name'],0777);
    $data = new Spreadsheet_Excel_Reader($_FILES['file_data_transaksi']['name'],false);

        $baris = $data->rowcount($sheet_index=0);
        $column = $data->colcount($sheet_index=0);
        //import data excel dari baris kedua, karena baris pertama adalah nama kolom
        // $temp_date = $temp_produk = "";
        $tgl="";
        $no=1;
        for ($i=2; $i<=$baris; $i++) {
            for($c=1; $c<=$column; $c++){
                $value[$c] = $data->val($i, $c);
            }


                    $tid = $value[1];
                    $id_item = $value[2];
                    $item = $value[3];
                    $id_penjualan = $value[4];
                    $date = format_date($value[5]);



                
                    $sql = "INSERT INTO transaksi (tid, id_item, produk, id_penjualan, tanggal_transaksi) VALUES ";
                    $value_in = array();
                    
                    $sql .= " ('$tid', '$id_item', '$item', '$id_penjualan', '$date')";
                    $db_object->db_query($sql) or die(mysql_error());


        }

        // hapus kembali file .xls yang di upload tadi
        unlink($_FILES['file_data_transaksi']['name']);

        ?>
        <script> location.replace("?menu=data_transaksi&pesan_success=Data berhasil disimpan"); </script>
        <?php
}

if(isset($_POST['delete'])){
    $sql = "TRUNCATE transaksi";
    $db_object->db_query($sql);
    ?>
        <script> location.replace("?menu=data_transaksi&pesan_success=Data transaksi berhasil dihapus"); </script>
        <?php
}

$sql = "SELECT
        *
        FROM
         transaksi, produk, penjualan WHERE transaksi.id_item=produk.id AND transaksi.id_penjualan=penjualan.id_penjualan";
$query=$db_object->db_query($sql);
$jumlah=$db_object->db_num_rows($query);
?>

<div class="super_sub_content">
    <div class="container">
        <div class="row">
            <!--UPLOAD EXCEL FORM-->
            <form method="post" enctype="multipart/form-data" action="">
                <div class="form-group">
                    <div class="input-group">
                        <label>Import data from excel</label>
                        <input name="file_data_transaksi" type="file" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <input name="submit" type="submit" value="Upload Data" class="btn btn-success">
                </div>
                <div class="form-group">
                    <button name="delete" type="submit"  class="btn btn-danger" >
                        <i class="fa fa-trash-o"></i> Delete All Data Transaction
                    </button>
                </div>
            </form>

            <?php
            if (!empty($pesan_error)) {
                display_error($pesan_error);
            }
            if (!empty($pesan_success)) {
                display_success($pesan_success);
            }


            echo "Jumlah data: ".$jumlah."<br>";
            if($jumlah==0){
                    echo "Data kosong...";
            }
            else{
            ?>
            <table class='table table-bordered table-striped  table-hover'>
                <tr>
                <th>No</th>
                <th>Id Transaksi</th>
                <th>Id Item</th>
                <th>Nama Produk</th>
                <th>Tanggal Transaksi</th>
                <th>Jenis Penjualan</th>
                </tr>
                <?php
                    $no=1;
                    while($row=$db_object->db_fetch_array($query)){
                        echo "<tr>";
                            echo "<td>".$no."</td>";
                            echo "<td>".$row['tid']."</td>";
                            echo "<td>".$row['id_item']."</td>";
                            echo "<td>".$row['produk']."</td>";
                            echo "<td>".$row['tanggal_transaksi']."</td>";
                            echo "<td>".$row['penjualan']."</td>";
                        echo "</tr>";
                        $no++;
                    }
                    ?>
            </table>
            <?php
            }
            ?>
        </div>
    </div>
</div>

<?php
function get_produk_to_in($produk){
    $ex = explode(",", $produk);
    //$temp = "";
    for ($i=0; $i < count($ex); $i++) { 

        $jml_key = array_keys($ex, $ex[$i]);
        if(count($jml_key)>1){
            unset($ex[$i]);
        }

        //$temp = $ex[$i];
    }
    return implode(",", $ex);
}

?>