<?php
//session_start();
session_start();
if (!isset($_SESSION['fpg_id'])) {
    header("location:index.php?menu=forbidden");
}

include_once "database.php";
$db_object = new database();
if($_GET["aksi"]=="simpan"){
$sql = "INSERT INTO penjualan (penjualan) VALUES ('$_POST[area]')";
$query=$db_object->db_query($sql);
}elseif($_GET["aksi"]=="edit"){
$sql = "UPDATE penjualan SET penjualan='$_POST[penjualan]' WHERE id_penjualan='$_POST[id_area]'";
$query=$db_object->db_query($sql);
}elseif($_GET['aksi']=='hapus'){
$sql = "DELETE FROM penjualan WHERE id_penjualan='$_GET[id]'";
	$query=$db_object->db_query($sql);
}

header("location:index.php?menu=area");
?>

