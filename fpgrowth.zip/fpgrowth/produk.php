<?php
//session_start();
session_start();
if (!isset($_SESSION['fpg_id'])) {
    header("location:index.php?menu=forbidden");
}

include_once "database.php";
$db_object = new database();
$sql = "SELECT
        *
        FROM
         produk";
$query=$db_object->db_query($sql);

?>
<section class="page_head">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="page_title">
                    <h2>Input Produk</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="super_sub_content">
    <div class="container">
        <div class="row">

            <form method="post"  action="aksi_produk.php?aksi=simpan">
                <div class="form-group">
                    <div class="input-group">
                        <label>Nama Produk</label>
                        <input name="produk" type="text" class="form-control" required>
                    </div>
                </div>
                <?php  
                    $sql_tipe="SELECT * FROM tipe ORDER BY tipe";
                    $query_tipe=$db_object->db_query($sql_tipe);
                ?>
                <div class="form-group">
                    <div class="input-group">
                        <label>Tipe</label><br>
                       <select name="tipe" class="form-control" required>
                            <option> Pilih Tipe </option>
                           <?php  
                                 while($row_tipe=$db_object->db_fetch_array($query_tipe)){
                                    ?>
                                    <option value='<?php echo $row_tipe[tipe] ?>'><?php echo $row_tipe['tipe'] ?></option>";
                               <?php   }
                           ?>
                       </select>
                    </div>
                </div>
                <div class="form-group">
                    <input name="submit" type="submit" value="Simpan Data" class="btn btn-success">
                </div>
            </form>
        </div>
        <table class='table table-bordered table-striped  table-hover'>
                <tr>
                <th>No</th>
                <th>Nama Produk</th>
                <th>Tipe</th>
                <th>Aksi</th>
                </tr>
                <?php
                    $no=1;
                    while($row=$db_object->db_fetch_array($query)){
                        echo "<tr>";
                            echo "<td>".$no."</td>";
                            echo "<td>".$row['produk']."</td>";
                            echo "<td>".$row['tipe']."</td>";
                        ?>
                        <td>
                            
                            <a href="aksi_produk.php?aksi=hapus&id=<?php echo $row['id'] ?>"><i class="fa fa-trash-o"></i></a>
                        </td>
                        <?php 
                        echo "</tr>";
                        $no++;
                    }
                ?>
            </table>
    </div>
</div>
