<div class="swiper-container">
    <div class="swiper-wrapper">

        <div class="swiper-slide" style="background-image: url(images/image1.jpg);">
            <div class="overlay-1"></div>
            <div class="slider-caption">
                <div class="inner-content">
                    <h2>Data Mining FP-GROWTH</h2>
                    <p>PENERAPAN ALGORITMA FP-GROWTH DALAM MENENTUKAN POLA PEMBELIAN KONSUMEN PADA TOKO TENUN UNGGAN LANSEK ( MANIH INDRA YENI)
                    <!-- <a href="#" class="main-btn white">View Projects</a> -->
                </div> <!-- /.inner-content -->
            </div> <!-- /.slider-caption -->
        </div> <!-- /.swier-slide -->

        <div class="swiper-slide" style="background-image: url(images/image2.jpg);">
            <div class="overlay-s"></div>
            <div class="slider-caption">
                <div class="inner-content">
                    <h2>Data Mining FP-GROWTH</h2>
                    <p>PENERAPAN ALGORITMA FP-GROWTH DALAM MENENTUKAN POLA PEMBELIAN KONSUMEN PADA TOKO TENUN UNGGAN LANSEK ( MANIH INDRA YENI)
                    <!-- <a href="#" class="main-btn white">View Projects</a> -->
                </div> <!-- /.inner-content -->
            </div> <!-- /.slider-caption -->
        </div> <!-- /.swier-slide -->

        <div class="swiper-slide" style="background-image: url(images/image3.jpg);">
            <div class="overlay-s"></div>
            <div class="slider-caption">
                <div class="inner-content">
                   <h2>Data Mining FP-GROWTH</h2>
                    <p>PENERAPAN ALGORITMA FP-GROWTH DALAM MENENTUKAN POLA PEMBELIAN KONSUMEN PADA TOKO TENUN UNGGAN LANSEK ( MANIH INDRA YENI)
                    <!-- <a href="#" class="main-btn white">View Projects</a> -->
                </div> <!-- /.inner-content -->
            </div> <!-- /.slider-caption -->
        </div> <!-- /.swier-slide -->

    </div> <!-- /.swiper-wrapper -->
</div> <!-- /.swiper-container -->