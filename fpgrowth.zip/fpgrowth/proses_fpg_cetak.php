<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cetak laporan</title>
</head>
<body>




<center>

<h4>Laporan Hasil Perhitungan Penentuan Pola Pembelian Konsumen</h4>
<h4>Pada Toko Tenun Unggan Lansek Manih (Indra Yeni) </h4>
<h4>Dengan Menggunakan Metode Frequent Pattern Growth (FP-Growth)</h4>

</center>
<?php
				$koneksi = mysqli_connect('localhost','root','','db_fpg') or die (mysqli_error());
				$sql = "SELECT * FROM hasil_temp";
				$query = mysqli_query($koneksi,$sql) or die (mysqli_error($koneksi));
				?>
	
		
	<br>	

	
	<?php


		
			

			$no = 1;

			$sql = "SELECT * FROM hasil_temp
			ORDER BY liftratio DESC";
			$query = mysqli_query($koneksi,$sql) or die (mysqli_error($koneksi));

			echo "<table border='1' class='table table-striped table-bordered' width='100%'>
					<thead align='center'>
						<tr align='center'>
                            <th>No</th>
							<th>Spesifikasi</th>
							<th>Liftratio</th>
							
						</tr>
					</thead>
					<tbody>";

					while($data1 = mysqli_fetch_array($query)){?>
						
						<tr align="center">
                            <td><?php echo $no;?></td>
							<td><?php echo $data1['spesifikasi'];?></td>
							<td><?php echo $data1['liftratio'];?></td>
							
						</tr>

						<?php $no++; ?>

					<?php }

			echo "	</tbody>
				  </table>";

		
			
	?>

<div align="right">
    <div>
	<p>Padang, <span id="tanggalwaktu"></span></p>
	<script>
	var tw = new Date();
	if (tw.getTimezoneOffset() == 0) (a=tw.getTime() + ( 7 *60*60*1000))
	else (a=tw.getTime());
	tw.setTime(a);
	var tahun= tw.getFullYear ();
	var hari= tw.getDay ();
	var bulan= tw.getMonth ();
	var tanggal= tw.getDate ();
	var hariarray=new Array("Minggu,","Senin,","Selasa,","Rabu,","Kamis,","Jum'at,","Sabtu,");
	var bulanarray=new Array("Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","Nopember","Desember");
	document.getElementById("tanggalwaktu").innerHTML = hariarray[hari]+" "+tanggal+" "+bulanarray[bulan]+" "+tahun;
	
	</script>
	</div>
	<br>
	<br>
	<br>
	
	<p>
		<u>(Indra Yeni)</u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	</p>
 </div>

</body>
</html>

<table>
 <script>
 window.print()
 </script>
 </table>