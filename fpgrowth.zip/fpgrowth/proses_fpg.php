<?php
session_start();
if (!isset($_SESSION['fpg_id'])) {
    header("location:index.php?menu=forbidden");
}

include_once "database.php";
include_once "fungsi.php";

?>
<section class="page_head">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="page_title">
                    <h2>Proses FP-GROWTH</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
//object database class
$db_object = new database();

//ambil data tipe
$sql_tipe="SELECT * FROM tipe ORDER BY tipe";
$query_tipe=$db_object->db_query($sql_tipe);


//ambil data area
$sql_area="SELECT * FROM penjualan ORDER BY penjualan";
$query_area=$db_object->db_query($sql_area);


$pesan_error = $pesan_success = "";
if (isset($_GET['pesan_error'])) {
    $pesan_error = $_GET['pesan_error'];
}
if (isset($_GET['pesan_success'])) {
    $pesan_success = $_GET['pesan_success'];
}

if (isset($_POST['submit'])) {
?>
    <div class="super_sub_content">
        <div class="container">
            <div class="row">
                    <form method="post" action="">
                        <div class="row">
                            <div class="col-lg-6 " >
                                <div class="form-group">
                                    <label>Min Support: </label>
                                    <!-- <select name="min_support" class="form-control" placeholder="Min Support">
                                            <option value="" disabled>Pilih</option>
                                            <option value="0.3"> 30%</option>
                                            <option value="0.55">55%</option>
                                            <option value="0.65">65%</option>
                                        </select> -->
                                        <input type="text" name="min_support" class="form-control" placeholder="Min Support contoh : 0.1">
                                </div>
                                <div class="form-group">
                                    <label>Min Confidence: </label>
                                    <!-- <select name="min_confidence" class="form-control" placeholder="Min Confidence">
                                            <option value="" disabled>Pilih</option>
                                            <option value="0.8">80%</option>
                                            <option value="0.85">85%</option>
                                            <option value="0.9">90%</option>
                                        </select> -->
                                        <input type="text" name="min_confidence" class="form-control" placeholder="min_confidence contoh : 0.2">
                                </div>
                                <input type="hidden" name="id_process" value="<?php echo $id_process; ?>">
                                <div class="form-group">
                                    <input name="submit" type="submit" value="Proses" class="btn btn-success">
                                    
                                    
                                </div>
                                <div>
                                <a href="proses_fpg_cetak.php" class="btn btn-primary fa fa-print">CETAK</a>
                                </div>
                            </div>
                            
                            <!-- <div class="col-lg-6 " >
                                <div class="form-group">
                                    <div class="input-group">
                                        <label>Tipe Produk: </label>
                                       <select name="tipe" class="form-control" required>
                                            <option> Pilih Tipe </option>
                                           <?php  
                                                 while($row_tipe=$db_object->db_fetch_array($query_tipe)){
                                                    ?>
                                                    <option value='<?php echo $row_tipe[tipe] ?>'><?php echo $row_tipe['tipe'] ?></option>";
                                               <?php   }
                                           ?>
                                       </select>
                                    </div>
                                </div>

                                 <div class="form-group">
                                <div class="input-group">
                                    <label>Area: </label>
                                       <select name="area" class="form-control" required>
                                            <option value=""> Pilih Area </option>
                                           <?php  
                                                 while($row_Penjualan=$db_object->db_fetch_array($query_area)){
                                                    ?>
                                                    <option value='<?php echo $row_Penjualan[penjualan] ?>'><?php echo $row_Penjualan['penjualan'] ?></option>";
                                               <?php   }
                                           ?>
                                       </select>
                                    </div>
                            </div>
                            </div> -->
                        </div>
                    </form>
                    <?php
                    
                    
                    echo "Min Support Absolut: " . $_POST['min_support'] *100 ." %";
                    echo "<br>";

                    echo "Min Confidence: " . $_POST['min_confidence'] * 100 ." %";
                    echo "<br>";

                    echo "<br>";
                    
                    $db_object= new database();
                    $sql = "TRUNCATE flist_temp";
                    $db_object->db_query($sql);

                    ?>
                    <h2>HEADER / F-LIST</h2>
                    <table border="1" class="table table-striped">
                        <th>NAMA ITEM</th><th>N(A)</th>
                            <?php
                                $minsup = $_POST['min_support'];
                                $header = $minsup*$jml;
                                $sql="SELECT DISTINCT(id_item), produk FROM transaksi";
                                $query4=$db_object->db_query($sql);
                        
                                

                                $q=$db_object->db_query("SELECT COUNT(DISTINCT id_item) AS jumlah FROM transaksi");
                                $query4count = $db_object->db_fetch_array($q);
                                $hasil = "";
                                
                                for($i = 1;$i<=$query4count['jumlah'];$i++)
                                {
                                    $row3 = $db_object->db_fetch_array($query4);
                                    $idit = $row3['id_item'];
                                    $qq = $db_object->db_query("SELECT COUNT(id_item) AS jumlah2 FROM transaksi WHERE id_item = '$idit' ");
                                    $hitungjmlidit= $db_object->db_fetch_array($qq);
                                    if($hitungjmlidit["jumlah2"] >= $header)
                                    {
                                        $db_object->db_query("INSERT INTO flist_temp (id_flist,hasil_flist,na) VALUES ('1','$idit','$hitungjmlidit') ");
                                        echo "<tr>";
                                        echo "<td>".$row3['produk']."</td>";
                                        echo "<td>".$hitungjmlidit["jumlah2"]."</td>";
                                        echo "</tr>";
                                    }
                                }
                            ?>
                        </tr>
                    </table>
                <?php    
                    $sqlx="DELETE FROM bench_lift"; 
                    $db_object->db_query($sqlx);
                    $sqly="DELETE FROM hasil_temp";
                    $db_object->db_query($sqly);

                    $j= $db_object->db_query("SELECT COUNT(DISTINCT tid) as jumlah from transaksi"); 
                    $q=$db_object->db_fetch_array($j);
                    $jml=$q['jumlah'];
                    ?>
                        <h1>Support dan Confidence</h1>
                            <table border='1' class="table table-striped"> 
                                <thead>
                                    <th>RULE</th>
                                    <th>COUNT</th>
                                    <th>SUPPORT</th>
                                    <th>CONFIDENCE</th>
                                </thead>
                                <tbody>
                                <?php

                                $kondisi_temp = $db_object->db_query("SELECT hasil_flist FROM flist_temp WHERE id_flist = 1");
                                $k_iditem = array("1","2","3","4","5","6","7","8","9");
                                $inputconf =$_POST['min_confidence'];
                                //function ngurutin data query 
                                function urut($data){
                                if($data){
                                    $data = explode(",", $data);
                                    sort($data);
                                    $hasil = "";
                                    foreach($data as $r => $d)
                                        {
                                            if($r != (count($data) -1)) $hasil .= "$d,";
                                            else $hasil .= "$d";
                                        }
                                            return $hasil;
                                    }
                                    return 0;
                                }
                                
                                //jadiin array data query
                                $row = array();
                                while($data = $db_object->db_fetch_array($kondisi_temp)){
                                    $row[] = urut($data[0]);
                                }
                                
                                //badingin hasil query dengan k_idiitem
                                foreach($k_iditem as $a => $b){
                                    foreach($row as $k)
                                
                                if($k == $b) $d[] = $a;
                                }
                                
                                //kondisi atau rule
                                //silahkan ganti sesuai dengan produk anda
                                if(in_array(0,$d) && in_array(3,$d) && in_array(4,$d))
                                {
                                    //$kondisi_count_transaksi = mysql_result(mysql_query("SELECT COUNT(*) AS jml FROM(SELECT SUM(IF(id_item=5 OR id_item=4 OR id_item=1,1,0)) AS n FROM transaksi GROUP BY tid) a WHERE a.n=3"),0);
                                    $kct = $db_object->db_query("SELECT COUNT(*) AS jml FROM(SELECT SUM(IF(id_item=5 OR id_item=4 OR id_item=1,1,0)) AS n FROM transaksi GROUP BY tid) a WHERE a.n=3");
                                    $kondisi_count_transaksi = $db_object->db_fetch_array($kct);
                                    $sa = $db_object->db_query("SELECT COUNT(*) AS jml FROM(SELECT SUM(IF(id_item=4 OR id_item=1,1,0)) AS n FROM transaksi GROUP BY tid) a WHERE a.n=2");
                                    $sqla = $db_object->db_fetch_array($sa);
                                    $support = ($sqla['jml']/$jml)*100;
                                    $itemconsequentx = $db_object->db_query("SELECT COUNT(*) as jml FROM transaksi WHERE id_item = 5");
                                    $itemconsequent = $db_object->db_fetch_array($itemconsequentx);
                                    $confidence = (($kondisi_count_transaksi['jml']/$sqla['jml'])*100)/100;
                                    $confidence = number_format($confidence,2);
                                    $item = "Pucuak paku & Rabuang => Pandai Sikek";
                                    $benchmark = $itemconsequent['jml']/$jml;
                                    $liftratio = $confidence/$benchmark;
                                    $liftratio = number_format($liftratio,2);
                                    $spesifikasi = "Jika ada pembelian Pucuak Paku dan Rabuang maka akan ada pembelian Pandai Sikek";
                                    echo "<tr>";
                                    echo "<td>Rule 1 & 4 => 5</td>";
                                    echo "<td>".$kondisi_count_transaksi['jml']."</td>";
                                    echo "<td>".$support."</td>";
                                    echo "<td>";
                                    if($confidence >= $inputconf) { echo $confidence; }
                                    echo "</td>";
                                    echo "</tr>";
                                    $db_object->db_query("INSERT INTO bench_lift(item,count,support,confidence,itemconsequent,benchmark,liftratio) VALUES ('$item','$kondisi_count_transaksi[jml]','$support','$confidence','$itemconsequent[jml]','$benchmark','$liftratio')");
                                    $db_object->db_query("INSERT INTO hasil_temp(spesifikasi,liftratio) VALUES ('$spesifikasi','$liftratio')");
                                }
                                if(in_array(0,$d) && in_array(3,$d) && in_array(1,$d))
                                {
                                    $kct=$db_object->db_query("SELECT COUNT(*) AS jml FROM(SELECT SUM(IF(id_item=4 OR id_item=2 OR id_item=1,1,0)) AS n FROM transaksi GROUP BY tid) a WHERE a.n=3");
                                    $kondisi_count_transaksi = $db_object->db_fetch_array($kct) ;
                                    $sa=$db_object->db_query("SELECT COUNT(*) AS jml FROM(SELECT SUM(IF(id_item=4 OR id_item=1,1,0)) AS n FROM transaksi GROUP BY tid) a WHERE a.n=2");
                                    $sqla = $db_object->db_fetch_array($sa) ;
                                    $support = ($sqla['jml']/$jml)*100;
                                    $itemconsequentx = $db_object->db_query("SELECT COUNT(*) as jml FROM transaksi WHERE id_item = 2");
                                    $itemconsequent=$db_object->db_fetch_array($itemconsequentx);
                                    $confidence = (($kondisi_count_transaksi['jml']/$sqla['jml'])*100)/100;
                                    $confidence = number_format($confidence,2);
                                    $item = "Saribu Bukik & Pucuak Paku => Rabuang";
                                    $benchmark = $itemconsequent['jml']/$jml;
                                    $liftratio = $confidence/$benchmark;
                                    $liftratio = number_format($liftratio,2);
                                    $spesifikasi = "Jika ada penjualan Saribu Bukik dan Pucuak Paku maka akan ada penjualan Mampan Perak - Rabuang";
                                    echo "<tr>";
                                    echo "<td>Rule 1 & 4 => 2</td>";
                                    echo "<td>".$kondisi_count_transaksi['jml']."</td>";
                                    echo "<td>".$support."</td>";
                                    echo "<td>";
                                    if($confidence >= $inputconf) { echo $confidence; }
                                    echo "</td>";
                                    echo "</tr>";
                                    $db_object->db_query("INSERT INTO bench_lift(item,count,support,confidence,itemconsequent,benchmark,liftratio) VALUES ('$item','$kondisi_count_transaksi[jml]','$support','$confidence','$itemconsequent[jml]','$benchmark','$liftratio')");
                                    $db_object->db_query("INSERT INTO hasil_temp(spesifikasi,liftratio) VALUES ('$spesifikasi','$liftratio')");
                                }
                                if(in_array(0,$d) && in_array(1,$d))
                                {
                                    $kct=$db_object->db_query("SELECT COUNT(*) AS jml FROM(SELECT SUM(IF(id_item=2 OR id_item=1,1,0)) AS n FROM transaksi GROUP BY tid) a WHERE a.n=2");
                                    $kondisi_count_transaksi = $db_object->db_fetch_array($kct) ;
                                    $sa=$db_object->db_query("SELECT COUNT(*) AS jml FROM transaksi WHERE id_item = 1");
                                    $sqla = $db_object->db_fetch_array($sa) ;
                                    $support = ($sqla['jml']/$jml)*100;
                                    $itemconsequentx = $db_object->db_query ("SELECT COUNT(*) as jml FROM transaksi WHERE id_item = 2");
                                    $itemconsequent = $db_object->db_fetch_array($itemconsequentx);
                                    $confidence = (($kondisi_count_transaksi['jml']/$sqla['jml'])*100)/100;
                                    $confidence = number_format($confidence,2);
                                    $item = "Saribu Bukik & Pandai Sikek";
                                    $benchmark = $itemconsequent['jml']/$jml;
                                    $liftratio = $confidence/$benchmark;
                                    $liftratio = number_format($liftratio,2);
                                    $spesifikasi = "Jika ada penjualan Saribu Bukik maka akan ada penjualan Pandai Sikek";
                                    echo "<tr>";
                                    echo "<td>Rule 1 => 2</td>";
                                    echo "<td>".$kondisi_count_transaksi['jml']."</td>";
                                    echo "<td>".$support."</td>";
                                    echo "<td>";
                                    if($confidence >= $inputconf) { echo $confidence; }
                                    echo "</td>";
                                    echo "</tr>";
                                    $db_object->db_query("INSERT INTO bench_lift(item,count,support,confidence,itemconsequent,benchmark,liftratio) VALUES ('$item','$kondisi_count_transaksi[jml]','$support','$confidence','$itemconsequent[jml]','$benchmark','$liftratio')");
                                    $db_object->db_query("INSERT INTO hasil_temp(spesifikasi,liftratio) VALUES ('$spesifikasi','$liftratio')");
                                }
                                if(in_array(5,$d) && in_array(0,$d))
                                {
                                    $kct=$db_object->db_query("SELECT COUNT(*) AS jml FROM(SELECT SUM(IF(id_item=8 OR id_item=6,1,0)) AS n FROM transaksi GROUP BY tid) a WHERE a.n=2");
                                    $kondisi_count_transaksi = $db_object->db_fetch_array($kct);
                                    $sa=$db_object->db_query("SELECT COUNT(*) AS jml FROM transaksi WHERE id_item = 8");
                                    $sqla = $db_object->db_fetch_array($sa);
                                    $support = ($sqla['jml']/$jml)*100;
                                    $itemconsequentx=$db_object->db_query("SELECT COUNT(*) as jml FROM transaksi WHERE id_item = 1");
                                    $itemconsequent = $db_object->db_fetch_array($itemconsequentx);
                                    $confidence = (($kondisi_count_transaksi['jml']/$sqla['jml'])*100)/100;
                                    $confidence = number_format($confidence,2);
                                    $item = "Lansek Manih - Super Double & Saribu Bukik";
                                    $benchmark = $itemconsequent['jml']/$jml;
                                    $liftratio = $confidence/$benchmark;
                                    $liftratio = number_format($liftratio,2);
                                    $spesifikasi = "Jika ada penjualan Lansek Manih - Super Double maka akan ada penjualan Saribu Bukik";
                                    echo "<tr>";
                                    echo "<td>Rule 6 => 1</td>";
                                    echo "<td>".$kondisi_count_transaksi['jml']."</td>";
                                    echo "<td>".$support."</td>";
                                    echo "<td>";
                                    if($confidence >= $inputconf) { echo $confidence; }
                                    echo "</td>";
                                    echo "</tr>";
                                    $db_object->db_query("INSERT INTO bench_lift(item,count,support,confidence,itemconsequent,benchmark,liftratio) VALUES ('$item','$kondisi_count_transaksi[jml]','$support','$confidence','$itemconsequent[jml]','$benchmark','$liftratio')");
                                    $db_object->db_query("INSERT INTO hasil_temp(spesifikasi,liftratio) VALUES ('$spesifikasi','$liftratio')");
                                }
                                if(in_array(4,$d) && in_array(0,$d))
                                {
                                    $kct=$db_object->db_query("SELECT COUNT(*) AS jml FROM(SELECT SUM(IF(id_item=5 OR id_item=1,1,0)) AS n FROM transaksi GROUP BY tid) a WHERE a.n=2");
                                    $kondisi_count_transaksi = $db_object->db_fetch_array($kct);
                                    $sa=$db_object->db_query("SELECT COUNT(*) AS jml FROM transaksi WHERE id_item = 5");
                                    $sqla = $db_object->db_fetch_array($sa);
                                    $support = ($sqla['jml']/$jml)*100;
                                    $itemconsequentx=$db_object->db_query("SELECT COUNT(*) as jml FROM transaksi WHERE id_item = 1");
                                    $itemconsequent = $db_object->db_fetch_array($itemconsequentx);
                                    $confidence = (($kondisi_count_transaksi['jml']/$sqla['jml'])*100)/100;
                                    $confidence = number_format($confidence,2);
                                    $item = "Mampan Perak - Rabuang & Saribu Bukik";
                                    $benchmark = $itemconsequent['jml']/$jml;
                                    $liftratio = $confidence/$benchmark;
                                    $liftratio = number_format($liftratio,2);
                                    $spesifikasi = "Jika ada penjualan Mampan Perak - Rabuang maka akan ada penjualan Saribu Bukik";
                                    echo "<tr>";
                                    echo "<td>Rule 5 => 1</td>";
                                    echo "<td>".$kondisi_count_transaksi['jml']."</td>";
                                    echo "<td>".$support."</td>";
                                    echo "<td>";
                                    if($confidence >= $inputconf) { echo $confidence; }
                                    echo "</td>";
                                    echo "</tr>";
                                   $db_object->db_query("INSERT INTO bench_lift(item,count,support,confidence,itemconsequent,benchmark,liftratio) VALUES ('$item','$kondisi_count_transaksi[jml]','$support','$confidence','$itemconsequent[jml]','$benchmark','$liftratio')");
                                    $db_object->db_query("INSERT INTO hasil_temp(spesifikasi,liftratio) VALUES ('$spesifikasi','$liftratio')");
                                }
                                if(in_array(2,$d) && in_array(0,$d))
                                {
                                    $kct=$db_object->db_query("SELECT COUNT(*) AS jml FROM(SELECT SUM(IF(id_item=3 OR id_item=1,1,0)) AS n FROM transaksi GROUP BY tid) a WHERE a.n=2");
                                    $kondisi_count_transaksi = $db_object->db_fetch_array($kct);
                                    $sa=$db_object->db_query("SELECT COUNT(*) AS jml FROM transaksi where id_item = 3");
                                    $sqla = $db_object->db_fetch_array($sq);
                                    $support = ($sqla['jml']/$jml)*100;
                                    $itemconsequentx=$db_object->db_query("SELECT COUNT(*) as jml FROM transaksi WHERE id_item = 1");
                                    $itemconsequent = $db_object->db_fetch_array($itemconsequentx);
                                    $confidence = (($kondisi_count_transaksi['jml']/$sqla['jml'])*100)/100;
                                    $confidence = number_format($confidence,2);
                                    $item = "Mampan Perak & Saribu Bukik";
                                    $benchmark = $itemconsequent['jml']/$jml;
                                    $liftratio = $confidence/$benchmark;
                                    $liftratio = number_format($liftratio,2);
                                    $spesifikasi = "Jika ada penjualan Mampan Perak maka akan ada penjualan Saribu Bukik";
                                    echo "<tr>";
                                    echo "<td>Rule 3 => 1</td>";
                                    echo "<td>".$kondisi_count_transaksi['jml']."</td>";
                                    echo "<td>".$support."</td>";
                                    echo "<td>";
                                    if($confidence >= $inputconf) { echo $confidence; }
                                    echo "</td>";
                                    echo "</tr>";
                                    $db_object->db_query("INSERT INTO bench_lift(item,count,support,confidence,itemconsequent,benchmark,liftratio) VALUES ('$item','$kondisi_count_transaksi[jml]','$support','$confidence','$itemconsequent[jml]','$benchmark','$liftratio')");
                                    $db_object->db_query("INSERT INTO hasil_temp(spesifikasi,liftratio) VALUES ('$spesifikasi','$liftratio')");
                                }
                               if(in_array(3,$d) && in_array(0,$d))
                                {
                                    $kct=$db_object->db_query("SELECT COUNT(*) AS jml FROM(SELECT SUM(IF(id_item=4 OR id_item=1,1,0)) AS n FROM transaksi GROUP BY tid) a WHERE a.n=2");
                                    $kondisi_count_transaksi = $db_object->db_fetch_array($kct);
                                    $sa=$db_object->db_query("SELECT COUNT(*) AS jml FROM transaksi WHERE id_item = 4");
                                    $sqla = $db_object->db_fetch_array($sa);
                                    $support = ($sqla['jml']/$jml)*100;
                                    $itemconsequentx=$db_object->db_query("SELECT COUNT(*) as jml FROM transaksi WHERE id_item = 1");
                                    $itemconsequent = $db_object->db_fetch_array($itemconsequentx);
                                    $confidence = (($kondisi_count_transaksi['jml']/$sqla['jml'])*100)/100;
                                    $confidence = number_format($confidence,2);
                                    $item = "Pucuak Paku & Saribu Bukik";
                                    $benchmark = $itemconsequent['jml']/$jml;
                                    $liftratio = $confidence/$benchmark;
                                    $liftratio = number_format($liftratio,2);
                                    $spesifikasi = "Jika ada penjualan Pucuak Paku maka akan ada penjualan Saribu Bukikss";
                                    echo "<tr>";
                                    echo "<td>Rule 4 => 1</td>";
                                    echo "<td>".$kondisi_count_transaksi['jml']."</td>";
                                    echo "<td>".$support."</td>";
                                    echo "<td>";
                                    if($confidence >= $inputconf) { echo $confidence; }
                                    echo "</td>";
                                    echo "</tr>";
                                    $db_object->db_query("INSERT INTO bench_lift(item,count,support,confidence,itemconsequent,benchmark,liftratio) VALUES ('$item','$kondisi_count_transaksi[jml]','$support','$confidence','$itemconsequent[jml]','$benchmark','$liftratio')");
                                    $db_object->db_query("INSERT INTO hasil_temp(spesifikasi,liftratio) VALUES ('$spesifikasi','$liftratio')");
                                }
                        ?>
                    </tbody>
                </table>
                <h1>Benchmark dan Lift Ratio</h1>
                    <table border='1' class="table table-striped"> 
                    <thead>
                        <th>ITEM</th>
                        <th>COUNT</th>
                        <th>SUPPORT</th>
                        <th>CONFIDENCE</th>
                        <th>Frekuensi Item Consequent</th>
                        <th>BENCHMARK</th>
                        <th>LIFTRATIO</th>
                    </thead>
                    <tbody>
                            
                        <?php
                                $querybenchlift = $db_object->db_query("SELECT*FROM bench_lift");
                                while($row = $db_object->db_fetch_array($querybenchlift))
                                {
                                    echo "<tr>";
                                    echo "<td>".$row['item']."</td>";
                                    echo "<td>".$row['count']."</td>";
                                    echo "<td>".$row['support']."</td>";
                                    echo "<td>";
                                    if($row['confidence'] >= $inputconf) { echo $row['confidence']; }
                                    echo "</td>";
                                    echo "<td>".$row['itemconsequent']."</td>";
                                    echo "<td>".$row['benchmark']."</td>";
                                    echo "<td>".$row['liftratio']."</td>";
                                    echo "</tr>";
                                }
                            ?>
                    </tbody>
                </table>
            <h1>Hasil</h1>
            <table border='1' class="table table-striped"> 
            <thead>
                <th>SPESIFIKASI</th>
                <th>LIFTRATIO</th>
            </thead>
            <tbody>
                    
                <?php
                        $queryhasil = $db_object->db_query("SELECT*FROM hasil_temp");
                        while($rowhasil = $db_object->db_fetch_array($queryhasil))
                        {
                            echo "<tr>";
                            echo "<td>".$rowhasil['spesifikasi']."</td>";
                            echo "<td>".$rowhasil['liftratio']."</td>";
                            echo "</tr>";
                        }
                    ?>
            </tbody>
            </table>    
                                       
                <!-- ================= -->
            </div>
        </div>
    </div>
    <?php
} else{
    ?>
    <div class="super_sub_content">
        <div class="container">
            <div class="row">
                    <form method="post" action="">
                        <div class="row">
                            <div class="col-lg-6 " >
                                <div class="form-group">
                                    <label>Min Support: </label>
                                    <!-- <select name="min_support" class="form-control" placeholder="Min Support">
                                            <option value="" disabled>Pilih</option>
                                            <option value="0.3"> 30%</option>
                                            <option value="0.55">55%</option>
                                            <option value="0.65">65%</option>
                                        </select> -->
                                        <input type="text" name="min_support" class="form-control" placeholder="Min Support contoh : 0.1">
                                </div>
                                <div class="form-group">
                                    <label>Min Confidence: </label>
                                    <!-- <select name="min_confidence" class="form-control" placeholder="Min Confidence">
                                            <option value="" disabled>Pilih</option>
                                            <option value="0.8">80%</option>
                                            <option value="0.85">85%</option>
                                            <option value="0.9">90%</option>
                                        </select> -->
                                        <input type="text" name="min_confidence" class="form-control" placeholder="min_confidence contoh : 0.2">
                                </div>
                                <input type="hidden" name="id_process" value="<?php echo $id_process; ?>">
                                <div class="form-group">
                                    <input name="submit" type="submit" value="Proses" class="btn btn-success">
                                </div>

                            </div>
                            <!-- <div class="col-lg-6 " >
                                <div class="form-group">
                                    <div class="input-group"><label>Tipe Produk: </label>
                                       <select name="tipe" class="form-control" required>
                                            <option> Pilih Tipe </option>
                                           <?php  
                                                 while($row_tipe=$db_object->db_fetch_array($query_tipe)){
                                                    ?>
                                                    <option value='<?php echo $row_tipe[tipe] ?>'><?php echo $row_tipe['tipe'] ?></option>";
                                               <?php   }
                                           ?>
                                       </select>
                                    </div>
                                </div>

                                 <div class="form-group">
                                <div class="input-group">
                                    <label>Area: </label>
                                       <select name="area" class="form-control" required>
                                            <option value=""> Pilih Area </option>
                                           <?php  
                                                 while($row_Penjualan=$db_object->db_fetch_array($query_area)){
                                                    ?>
                                                    <option value='<?php echo $row_Penjualan[penjualan] ?>'><?php echo $row_Penjualan['penjualan'] ?></option>";
                                               <?php   }
                                           ?>
                                       </select>
                                    </div>
                            </div>
                            </div> -->
                        </div>
                    </form>
            </div>
        </div>
    </div>

    <?php   
}
?>
