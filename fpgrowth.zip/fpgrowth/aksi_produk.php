<?php
//session_start();
session_start();
if (!isset($_SESSION['fpg_id'])) {
    header("location:index.php?menu=forbidden");
}

include_once "database.php";
$db_object = new database();
if($_GET["aksi"]=="simpan"){
$sql = "INSERT INTO produk (produk, tipe) VALUES ('$_POST[produk]', '$_POST[tipe]')";
$query=$db_object->db_query($sql);
}elseif($_GET["aksi"]=="edit"){
$sql = "UPDATE produk SET produk='$_POST[produk]', tipe='$_POST[tipe]' WHERE id='$_POST[id]'";
$query=$db_object->db_query($sql);
}else{
	$sql = "DELETE FROM produk WHERE id='$_GET[id]'";
$query=$db_object->db_query($sql);
}

header("location:index.php?menu=produk");
?>

