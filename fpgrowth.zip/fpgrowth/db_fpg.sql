-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 07, 2023 at 12:20 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_fpg`
--

-- --------------------------------------------------------

--
-- Table structure for table `area`
--

CREATE TABLE `area` (
  `id_area` int(11) NOT NULL,
  `area` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `area`
--

INSERT INTO `area` (`id_area`, `area`) VALUES
(1, 'Online'),
(2, 'Offline');

-- --------------------------------------------------------

--
-- Table structure for table `bench_lift`
--

CREATE TABLE `bench_lift` (
  `item` text NOT NULL,
  `count` varchar(100) NOT NULL,
  `support` varchar(100) NOT NULL,
  `confidence` varchar(100) NOT NULL,
  `itemconsequent` varchar(100) NOT NULL,
  `benchmark` varchar(100) NOT NULL,
  `liftratio` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bench_lift`
--

INSERT INTO `bench_lift` (`item`, `count`, `support`, `confidence`, `itemconsequent`, `benchmark`, `liftratio`) VALUES
('Pucuak paku & Rabuang => Pandai Sikek', '5', '60', '0.83', '7', '0.7', '1.19'),
('Saribu Bukik & Pucuak Paku => Rabuang', '5', '60', '0.83', '9', '0.9', '0.92'),
('Saribu Bukik & Pandai Sikek', '6', '150', '0.40', '9', '0.9', '0.44'),
('Lansek Manih - Super Double & Saribu Bukik', '2', '30', '0.67', '15', '1.5', '0.45'),
('Mampan Perak - Rabuang & Saribu Bukik', '6', '70', '0.86', '15', '1.5', '0.57'),
('Mampan Perak & Saribu Bukik', '4', '0', '0.00', '15', '1.5', '0.00'),
('Pucuak Paku & Saribu Bukik', '6', '120', '0.50', '15', '1.5', '0.33');

-- --------------------------------------------------------

--
-- Table structure for table `flist_temp`
--

CREATE TABLE `flist_temp` (
  `id_flist` int(11) NOT NULL,
  `hasil_flist` varchar(100) NOT NULL,
  `na` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=armscii8;

--
-- Dumping data for table `flist_temp`
--

INSERT INTO `flist_temp` (`id_flist`, `hasil_flist`, `na`) VALUES
(1, '3', 'Array'),
(1, '4', 'Array'),
(1, '2', 'Array'),
(1, '1', 'Array'),
(1, '5', 'Array'),
(1, '9', 'Array'),
(1, '6', 'Array'),
(1, '7', 'Array'),
(1, '8', 'Array');

-- --------------------------------------------------------

--
-- Table structure for table `hasil_temp`
--

CREATE TABLE `hasil_temp` (
  `spesifikasi` text NOT NULL,
  `liftratio` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hasil_temp`
--

INSERT INTO `hasil_temp` (`spesifikasi`, `liftratio`) VALUES
('Jika ada pembelian Pucuak Paku dan Rabuang maka akan ada pembelian Pandai Sikek', '1.19'),
('Jika ada penjualan Saribu Bukik dan Pucuak Paku maka akan ada penjualan Mampan Perak - Rabuang', '0.92'),
('Jika ada penjualan Saribu Bukik maka akan ada penjualan Pandai Sikek', '0.44'),
('Jika ada penjualan Lansek Manih - Super Double maka akan ada penjualan Saribu Bukik', '0.45'),
('Jika ada penjualan Mampan Perak - Rabuang maka akan ada penjualan Saribu Bukik', '0.57'),
('Jika ada penjualan Mampan Perak maka akan ada penjualan Saribu Bukik', '0.00'),
('Jika ada penjualan Pucuak Paku maka akan ada penjualan Saribu Bukikss', '0.33');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id` int(11) NOT NULL,
  `produk` varchar(50) NOT NULL,
  `tipe` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id`, `produk`, `tipe`) VALUES
(1, 'Saribu bukik', 'Kualitas A'),
(2, 'Pandai Sikek', 'kualitas A'),
(3, 'Mampan Perak', 'kualitas A'),
(4, 'Pucuak Paku', 'kualitas A'),
(5, 'Rabuang', 'kualitas A'),
(6, 'Lansek Manih', 'kualitas A'),
(7, 'Saik Kalamai', 'kualitas A'),
(8, 'Barantai Putiah', 'kualitas A'),
(9, 'Tampuak Manggih', 'Kualitas B');

-- --------------------------------------------------------

--
-- Table structure for table `tipe`
--

CREATE TABLE `tipe` (
  `id_tipe` int(11) NOT NULL,
  `tipe` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tipe`
--

INSERT INTO `tipe` (`id_tipe`, `tipe`) VALUES
(1, 'Kain Kualitas A'),
(3, 'Kain Kualitas B');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `no` int(11) NOT NULL,
  `tid` varchar(100) NOT NULL,
  `id_item` varchar(100) NOT NULL,
  `produk` varchar(100) NOT NULL,
  `id_area` int(11) NOT NULL,
  `tanggal_transaksi` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=armscii8;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`no`, `tid`, `id_item`, `produk`, `id_area`, `tanggal_transaksi`) VALUES
(1, '1', '3', 'Mampan Perak', 1, '2022-03-07'),
(2, '1', '3', 'Mampan Perak', 1, '2022-03-07'),
(3, '1', '4', 'Pucuak Paku', 2, '2022-03-07'),
(4, '1', '2', 'Pandai Sikek', 1, '2022-03-07'),
(5, '1', '1', 'Saribu Bukik', 2, '2022-03-07'),
(6, '1', '2', 'Pandai Sikek', 1, '2022-03-07'),
(7, '1', '4', 'Pucuak Paku', 1, '2022-03-07'),
(8, '1', '1', 'Saribu Bukik', 2, '2022-03-07'),
(9, '10', '5', 'Rabuang', 1, '2022-03-07'),
(10, '10', '2', 'Pandai Sikek', 1, '2022-03-07'),
(11, '10', '1', 'Saribu Bukik', 2, '2022-03-07'),
(12, '10', '4', 'Pucuak Paku', 1, '2022-03-07'),
(13, '10', '3', 'Mampan Perak', 2, '2022-03-07'),
(14, '10', '3', 'Mampan Perak', 1, '2022-03-07'),
(15, '2', '9', 'Tapuak Manggih', 2, '2022-03-07'),
(16, '2', '1', 'Saribu Bukik', 1, '2022-03-07'),
(17, '2', '2', 'Pandai Sikek', 1, '2022-03-07'),
(18, '2', '5', 'Rabuang', 2, '2022-03-07'),
(19, '2', '4', 'Pucuak Paku', 1, '2022-03-07'),
(20, '2', '6', 'Lansek Manih', 2, '2022-03-07'),
(21, '2', '9', 'Tapuak Manggih', 1, '2022-03-07'),
(22, '2', '7', 'Saik Kalamai', 1, '2022-03-07'),
(23, '2', '8', 'Barantai Putiah', 1, '2022-03-07'),
(24, '2', '1', 'Saribu Bukik', 2, '2022-03-07'),
(25, '3', '1', 'Saribu Bukik', 1, '2022-03-07'),
(26, '3', '3', 'Mampan Perak', 1, '2022-03-07'),
(27, '3', '1', 'Saribu Bukik', 1, '2022-03-07'),
(28, '3', '5', 'Rabuang', 1, '2022-03-07'),
(29, '3', '4', 'Pucuak Paku', 2, '2022-03-07'),
(30, '3', '4', 'Pucuak Paku', 1, '2022-03-07'),
(31, '3', '3', 'Mampan Perak', 1, '2022-03-07'),
(32, '4', '1', 'Saribu Bukik', 2, '2022-03-07'),
(33, '4', '1', 'Saribu Bukik', 1, '2022-01-01'),
(34, '4', '3', 'Mampan Perak', 1, '2022-03-07'),
(35, '4', '4', 'Pucuak Paku', 2, '2022-03-07'),
(36, '4', '1', 'Saribu Bukik', 1, '2022-03-07'),
(37, '4', '9', 'Tapuak Manggih', 1, '2022-03-07'),
(38, '4', '2', 'Pandai Sikek', 1, '2022-03-07'),
(39, '5', '1', 'Saribu Bukik', 1, '2022-03-07'),
(40, '5', '5', 'Rabuang', 2, '2022-03-07'),
(41, '5', '4', 'Pucuak Paku', 1, '2022-03-07'),
(42, '5', '3', 'Mampan Perak', 2, '2022-03-07'),
(43, '5', '2', 'Pandai Sikek', 1, '2022-03-07'),
(44, '5', '3', 'Mampan Perak', 1, '2022-03-07'),
(45, '6', '8', 'Barantai Putiah', 1, '2022-03-07'),
(46, '6', '3', 'Mampan Perak', 2, '2022-03-07'),
(47, '6', '2', 'Pandai Sikek', 2, '2022-03-07'),
(48, '6', '7', 'Saik Kalamai', 1, '2022-03-07'),
(49, '6', '1', 'Saribu Bukik', 2, '2022-03-07'),
(50, '6', '4', 'Pucuak Paku', 1, '2022-03-07'),
(51, '7', '1', 'Saribu Bukik', 1, '2022-03-07'),
(52, '7', '3', 'Mampan Perak', 2, '2022-03-07'),
(53, '7', '4', 'Pucuak Paku', 1, '2022-03-07'),
(54, '7', '6', 'Lansek Manih', 2, '2022-03-07'),
(55, '7', '5', 'Rabuang', 1, '2022-03-07'),
(56, '8', '1', 'Saribu Bukik', 1, '2022-03-07'),
(57, '8', '8', 'Barantai Putiah', 1, '2022-03-07'),
(58, '8', '7', 'Saik Kalamai', 2, '2022-03-07'),
(59, '8', '2', 'Pandai Sikek', 2, '2022-03-07'),
(60, '8', '4', 'Pucuak Paku', 2, '2022-03-07'),
(61, '8', '6', 'Lansek Manih', 1, '2022-03-07'),
(62, '8', '5', 'Rabuang', 1, '2022-03-07'),
(63, '9', '6', 'Lansek Manih', 1, '2022-03-07'),
(64, '9', '1', 'Saribu Bukik', 2, '2022-03-07'),
(65, '9', '3', 'Mampan Perak', 1, '2022-03-07'),
(66, '9', '5', 'Rabuang', 2, '2022-03-07'),
(67, '9', '4', 'Pucuak Paku', 1, '2022-03-07'),
(68, '9', '9', 'Tapuak Manggih', 2, '2022-03-07'),
(69, '9', '2', 'Pandai Sikek', 1, '2022-03-07');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(200) DEFAULT NULL,
  `nama` varchar(200) DEFAULT NULL,
  `password` text DEFAULT NULL,
  `level` tinyint(4) NOT NULL DEFAULT 0,
  `last_login` datetime DEFAULT NULL,
  `inactive` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `nama`, `password`, `level`, `last_login`, `inactive`) VALUES
(1, 'admin', 'Administrator', '21232f297a57a5a743894a0e4a801fc3', 1, '2017-02-22 01:49:04', 0),
(2, 'user', 'User Direktur', 'ee11cbb19052e40b07aac0ca060c23ee', 2, '2016-05-22 09:19:02', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `area`
--
ALTER TABLE `area`
  ADD PRIMARY KEY (`id_area`);

--
-- Indexes for table `flist_temp`
--
ALTER TABLE `flist_temp`
  ADD PRIMARY KEY (`hasil_flist`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `produk` (`produk`);

--
-- Indexes for table `tipe`
--
ALTER TABLE `tipe`
  ADD PRIMARY KEY (`id_tipe`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `area`
--
ALTER TABLE `area`
  MODIFY `id_area` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tipe`
--
ALTER TABLE `tipe`
  MODIFY `id_tipe` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
