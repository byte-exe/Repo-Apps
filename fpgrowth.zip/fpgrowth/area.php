<?php
//session_start();
session_start();
if (!isset($_SESSION['fpg_id'])) {
    header("location:index.php?menu=forbidden");
}

include_once "database.php";
$db_object = new database();
$sql = "SELECT
        *
        FROM
         penjualan ORDER BY penjualan";
$query=$db_object->db_query($sql);

?>
<section class="page_head">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="page_title">
                    <h2>Input Jenis Penjualan</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="super_sub_content">
    <div class="container">
        <div class="row">

            <form method="post"  action="aksi_area.php?aksi=simpan">
                <div class="form-group">
                    <div class="input-group">
                        <label>Jenis Penjualan</label>
                        <input name="area" type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <input name="submit" type="submit" value="Simpan Data" class="btn btn-success">
                </div>
            </form>
        </div>
        <table class='table table-bordered table-striped  table-hover'>
                <tr>
                <th>No</th>
                <th>Nama Area</th>
                <th>Aksi</th>
                </tr>
                <?php
                    $no=1;
                    while($row=$db_object->db_fetch_array($query)){
                        echo "<tr>";
                            echo "<td>".$no."</td>";
                            echo "<td>".$row['penjualan']."</td>";
                        ?>
                        <td>
                            
                            <a href="aksi_area.php?aksi=hapus&id=<?php echo $row['id_penjualan'] ?>"><i class="fa fa-trash-o"></i></a>
                        </td>
                        <?php 
                        echo "</tr>";
                        $no++;
                    }
                ?>
            </table>
    </div>
</div>
