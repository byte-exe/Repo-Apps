<?php
//session_start();
session_start();
if (!isset($_SESSION['fpg_id'])) {
    header("location:index.php?menu=forbidden");
}

include_once "database.php";
$db_object = new database();
if($_GET["aksi"]=="simpan"){
$sql = "INSERT INTO tipe (tipe) VALUES ('$_POST[tipe]')";
$query=$db_object->db_query($sql);
}elseif($_GET["aksi"]=="edit"){
$sql = "UPDATE tipe SET tipe='$_POST[tipe]' WHERE id_tipe='$_POST[id_tipe]'";
$query=$db_object->db_query($sql);
}else{
	$sql = "DELETE FROM tipe WHERE id_tipe='$_GET[id]'";
$query=$db_object->db_query($sql);
}

header("location:index.php?menu=tipe");
?>

