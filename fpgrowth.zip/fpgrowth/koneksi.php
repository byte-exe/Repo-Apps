<?php
/*
 * Configuration Database
 */
return array(
    'host' => "localhost",
    'username' => "root",
    'password' => "",
    'dbname' => "db_fpg",
    // 'port' => "", // sementara menggunakan port bawaan
);

?>
