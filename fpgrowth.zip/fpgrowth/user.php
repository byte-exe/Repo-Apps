<?php
//session_start();
if (!isset($_SESSION['apriori_toko_id'])) {
    header("location:index.php?menu=forbidden");
}

include_once "database.php";
include_once "fungsi.php";
include_once "import/excel_reader2.php";
?>
<section class="page_head">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="page_title">
                    <h2>Data User</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
//object database class
$db_object = new database();

$sql = "SELECT
        *
        FROM
         users";
$query=$db_object->db_query($sql);
$jumlah=$db_object->db_num_rows($query);
?>

<div class="super_sub_content">
    <div class="container">
        <div class="row">
            <!--UPLOAD EXCEL FORM-->
            <form method="post" action="aksi_user.php?aksi=simpan">
            <div class="form-group">
                    <div class="input-group">
                        <label>Nama</label>
                        <input name="nama" type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <label>Username</label>
                        <input name="username" type="text" class="form-control">
                    </div>
                </div>
               
                <div class="form-group">
                    <div class="input-group">
                        <label>Password</label>
                        <input name="password" type="password" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <label>Level</label>
                        <br>
                        <select name="level">
                            <option value="">Pilih Level</option>
                            <option value="1">Administrator</option>
                            <option value="1">-</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <input name="submit" type="submit" value="Simpan Data" class="btn btn-success">
                </div>
                
            </form>

             <table class='table table-bordered table-striped  table-hover'>
                <tr>
                <th>No</th>
                <th>Username</th>
                <th>Nama</th>
                <th>Level</th>
                <th>Aksi</th>
                </tr>
                <?php
                    $no=1;
                    while($row=$db_object->db_fetch_array($query)){
                         if($row["level"]==1)
                        {
                            $level="Administrator";
                        }else{
                             $level="User";
                        }
                        echo "<tr>";
                            echo "<td>".$no."</td>";
                            echo "<td>".$row['username']."</td>";
                            echo "<td>".$row['nama']."</td>";
                            echo "<td>".$level."</td>";
                        ?>
                        <td>
                            
                            <a href="aksi_user.php?aksi=hapus&username=<?php echo $row['username'] ?>"><i class="fa fa-trash-o"></i></a>
                        </td>
                        <?php 
                        echo "</tr>";
                        $no++;
                    }
                    ?>
            </table>
        </div>
    </div>
</div>

<?php
function get_produk_to_in($produk){
    $ex = explode(",", $produk);
    //$temp = "";
    for ($i=0; $i < count($ex); $i++) { 

        $jml_key = array_keys($ex, $ex[$i]);
        if(count($jml_key)>1){
            unset($ex[$i]);
        }

        //$temp = $ex[$i];
    }
    return implode(",", $ex);
}

?>