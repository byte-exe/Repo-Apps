<?php
session_start();
if (!isset($_SESSION['apriori_toko_id'])) {
    header("location:index.php?menu=forbidden");
}

include_once "database.php";
$db_object = new database();
if($_GET['aksi']=='simpan')
{
	$pass=MD5($_POST["password"]);
	$sql = "INSERT INTO users (username, nama, password, level) VALUES ('$_POST[username]', '$_POST[nama]', '$pass', '$_POST[level]')";
	$query=$db_object->db_query($sql);
}elseif($_GET['aksi']=='hapus'){
	$sql="DELETE FROM users WHERE username='$_GET[username]'";
	$query=$db_object->db_query($sql);
}elseif($_GET['aksi']=='edit'){
	$pass=MD5($_POST["password"]);
	$sql="UPDATE users SET nama='$_POST[nama]', password='$pass', level='$_POST[level]' WHERE username='$_POST[username]'";
	$query=$db_object->db_query($sql);
}

header("location:index.php?menu=user");
?>

